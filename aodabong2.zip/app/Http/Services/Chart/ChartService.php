<?php

namespace App\Http\Services\Chart;

class ChartService
{
    public function barChart()
    {
    }
}